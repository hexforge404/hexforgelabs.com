import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminPage.css';
import API_BASE_URL from '../utils/apiBase';
import { useCart } from '../context/CartContext';
import { toast } from 'react-toastify';

export default function AdminPage() {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    name: '',
    description: '',
    price: '',
    image: '',
    brand: 'HexForge',
    stock: 0,
    categories: '',
    isFeatured: false
  });
  const [existingNames, setExistingNames] = useState([]);
  const isDuplicateName = form.name.trim() && existingNames.includes(form.name.trim().toLowerCase());


  const [editStatus, setEditStatus] = useState({});
  const [orderStatus, setOrderStatus] = useState({});
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [productsRes, ordersRes] = await Promise.all([
          axios.get(`${API_BASE_URL}/products`),
          axios.get(`${API_BASE_URL}/orders`)
        ]);

        const productList = Array.isArray(productsRes.data.data) ? productsRes.data.data : [];
        setProducts(productList);
        setExistingNames(productList.map(p => p.name.trim().toLowerCase()));
        
        setOrders(Array.isArray(ordersRes.data.data) ? ordersRes.data.data : []);
      } catch (err) {
        setError(`Failed to load data: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);
  const { cart } = useCart();
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const handleCheckout = async () => {
    if (cart.length === 0) {
      alert('⚠️ Your cart is empty!');
      return;
    }
    try {
      const res = await fetch(`${API_BASE_URL}/payments/create-checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: cart }),
        credentials: 'include',
      });
      const data = await res.json();
      if (data.url) {
        // Save cart to localStorage before redirecting
        localStorage.setItem('cartItems', JSON.stringify(cart));
        window.location.href = data.url;
      } else {
        alert('❌ Stripe Checkout failed. No URL received.');
      }
    } catch (err) {
      console.error('Checkout error:', err);
      alert('⚠️ Something went wrong during checkout.');
    }
  };
  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this order?')) return;
    try {
      await axios.delete(`${API_BASE_URL}/products/${id}`);
setProducts(prev => prev.filter(p => p._id !== id)); // ✅ correct state

      toast.success('Order deleted successfully');
    } catch (err) {
      console.error('Error deleting order:', err);
      toast.error('Failed to delete order');
    }
  };
  const handleStatusUpdate = async (orderId, newStatus) => {
    try {
      const response = await axios.patch(`${API_BASE_URL}/orders/${orderId}`, { 
        status: newStatus
      });
      setOrders(prev => prev.map(order => order._id === orderId ? response.data : order));
      toast.success(`Order status updated to ${newStatus}`);
    } catch (err) {
      console.error('Error updating order status:', err);
      toast.error('Failed to update order status');
    }
  };

  async function addProduct() {
    if (!form.name || !form.price || !form.brand || !form.image) {
      setError('All fields except categories are required.');
      return;
    }
    try {
      const productData = {
        name: form.name.trim(),
        description: form.description?.trim() || '',
        price: parseFloat(form.price),
        image: form.image.trim(),
        brand: form.brand.trim(),
        stock: Number(form.stock),
        isFeatured: Boolean(form.isFeatured),
        categories: form.categories
          ? form.categories.split(',').map(cat => cat.trim()).filter(Boolean)
          : []
      };
      console.log('[DEBUG] Sending new product:', productData);

      const res = await axios.post(`${API_BASE_URL}/products`, productData);
      if (res.status !== 201) {
        throw new Error('Failed to add product');
      }
      console.log('[DEBUG] Product added successfully:', res.data);
      setExistingNames(prev => [...prev, res.data.name.trim().toLowerCase()]);

      setProducts(prev => [...prev, res.data]);
      setForm({ name: '', description: '', price: '', image: '', brand: 'HexForge', stock: 0, categories: '', isFeatured: false });
      setSuccess('Product added successfully!');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(`Failed to add product: ${err.response?.data?.message || err.response?.data?.error || err.message}`);
      console.error('[DEBUG] Error adding product:', err);
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const updateProduct = async (id, field, value) => {
    setEditStatus(prev => ({ ...prev, [id]: 'saving' }));
    try {
      const original = products.find(p => p._id === id);

// Ensure SKU is always included
const updated = {
  ...original,
  [field]: value,
  sku: original.sku // ✅ include existing SKU
};

const res = await axios.put(`${API_BASE_URL}/products/${id}`, updated);

      if (res.status !== 200) {
        throw new Error('Failed to update product');
      }
      console.log('[DEBUG] Product updated successfully:', res.data);
      setExistingNames(prev => {
        const updatedNames = [...prev];
        const index = updatedNames.indexOf(products.find(p => p._id === id).name.trim().toLowerCase());
        if (index !== -1) {
          updatedNames[index] = res.data.name.trim().toLowerCase();
        }
        return updatedNames;
      });
      setProducts(prev => prev.map(p => p._id === id ? res.data : p));
      setEditStatus(prev => ({ ...prev, [id]: 'saved' }));
      setTimeout(() => setEditStatus(prev => ({ ...prev, [id]: null })), 2000);
    } catch (err) {
      setEditStatus(prev => ({ ...prev, [id]: 'error' }));
      setError(`Update failed: ${err.response?.data?.message || err.message}`);
    }
  };

  const deleteProduct = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try {
      await axios.delete(`${API_BASE_URL}/products/${id}`);
setProducts(prev => prev.filter(p => p._id !== id)); // ✅ fix

      setSuccess('Product deleted.');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(`Delete failed: ${err.response?.data?.message || err.message}`);
    }
  };

  

  if (loading) return <div className="admin-container" style={{ textAlign: 'center' }}><p style={{ color: '#00ffc8' }}>Loading...</p></div>;

  return (
    <div className="admin-container">
      {error && <div className="status-message error-message"><span>{error}</span><button onClick={() => setError(null)} className="close-button">×</button></div>}
      {success && <div className="status-message success-message"><span>{success}</span><button onClick={() => setSuccess(null)} className="close-button">×</button></div>}
      <h2 className="section-header">ADMIN PANEL</h2>

      <div className="form-section">
        <h3 className="section-header">ADD NEW PRODUCT</h3>
        <div className="form-grid">
          {['name', 'description', 'price', 'image', 'brand', 'stock', 'categories'].map(field => (
            <div className="form-group" key={field}>
              <label className="form-label">{field.toUpperCase()}</label>
              {field === 'image' ? (
  <>
    <input
      name="image"
      type="text"
      value={form.image}
      onChange={handleInputChange}
      className="form-input"
      placeholder="Enter image path"
    />
    <input
      type="file"
      accept=".jpg,.jpeg,.png,.webp,.gif"
      onChange={e => {
        const file = e.target.files[0];
        if (file) {
          const fileName = file.name.toLowerCase().replace(/\s+/g, '_');
          const path = `/images/${fileName}`;
          setForm(prev => ({ ...prev, image: path }));
        }
      }}
      className="form-input"
      style={{ marginTop: '6px' }}
    />
    {form.image && (
      <div style={{ marginTop: '8px' }}>
        <label className="form-label">PREVIEW</label><br />
        <img
          src={form.image}
          alt="Preview"
          style={{ maxHeight: '100px', borderRadius: '6px', border: '1px solid #333' }}
          onError={(e) => {
            e.target.onerror = null; // Prevent infinite loop
            e.target.src = '/images/placeholder.png'; // Placeholder image
          }}
          onLoad={(e) => {
            if (e.target.naturalWidth > 200 || e.target.naturalHeight > 200) {
              e.target.style.maxHeight = '200px';
            }
          }}
          className="image-preview"
          style={{
            marginTop: '8px',
            borderRadius: '6px',
            border: '1px solid #333',
            cursor: 'pointer',
            maxHeight: '200px'
          }}
          onClick={() => {
            const newWindow = window.open();
            newWindow.document.write(`<img src="${form.image}" style="max-width: 100%; height: auto;" />`);
          }}
          onMouseOver={(e) => {
            e.target.style.cursor = 'pointer';
          }}
          onMouseOut={(e) => {
            e.target.style.cursor = 'default';
          }}
        />
      </div>
    )}
  </>
) : (
  <input
    name={field}
    type={field === 'price' || field === 'stock' ? 'number' : 'text'}
    value={form[field]}
    onChange={handleInputChange}
    className="form-input"
    placeholder={`Enter ${field}`}
  />
)}

            </div>
          ))}
          {isDuplicateName && (
            <div style={{ color: '#ff4d4d', marginBottom: '8px' }}>
            ⚠ A product with this name already exists.
            <br />
            Please choose a different name.
            <br />
            <span style={{ fontSize: '12px' }}>
              (Names are case-insensitive)
            </span>
            <br />
            <span style={{ fontSize: '12px' }}>
              (Spaces are ignored)
            </span>
            <br />
            </div>
          )}

        </div>
        <button
          onClick={addProduct}
          disabled={isDuplicateName}
          className="action-button add-button"
          style={isDuplicateName ? { opacity: 0.5, cursor: 'not-allowed' } : {}}
        >
           ➕ ADD PRODUCT
        </button>

      </div>

      <div className="form-section">
        <h3 className="section-header">EXISTING PRODUCTS ({products.length})</h3>
        {products.length > 0 ? (
          <div className="product-grid">
            {products.map(product => (
              <div key={product._id} className="product-card">
                {['name', 'description', 'price', 'image'].map(field => (
                  <div className="form-group" key={field}>
                    <label className="form-label">{field.toUpperCase()}</label>
                    <input
                      type={field === 'price' ? 'number' : 'text'}
                      value={product[field] || ''}
                      onChange={e => setProducts(prev => prev.map(p => p._id === product._id ? { ...p, [field]: e.target.value } : p))}
                      onBlur={() => updateProduct(product._id, field, product[field])}
                      className="form-input"
                    />
                  </div>
                ))}

                {product.image && <div className="form-group"><label className="form-label">IMAGE PREVIEW</label><img src={product.image} alt={product.name} className="image-preview" /></div>}

                <div className="form-group"><label className="form-label">BRAND</label>
                  <input type="text" value={product.brand || ''} onChange={e => setProducts(prev => prev.map(p => p._id === product._id ? { ...p, brand: e.target.value } : p))} onBlur={() => updateProduct(product._id, 'brand', product.brand)} className="form-input" />
                </div>
                <div className="form-group"><label className="form-label">STOCK</label>
                  <input type="number" value={product.stock || 0} onChange={e => setProducts(prev => prev.map(p => p._id === product._id ? { ...p, stock: parseInt(e.target.value) || 0 } : p))} onBlur={() => updateProduct(product._id, 'stock', product.stock)} className="form-input" />
                </div>
                <div className="form-group"><label className="form-label">CATEGORIES</label>
                  <input type="text" value={product.categories?.join(', ') || ''} onChange={e => setProducts(prev => prev.map(p => p._id === product._id ? { ...p, categories: e.target.value.split(',').map(c => c.trim()) } : p))} onBlur={() => updateProduct(product._id, 'categories', product.categories)} className="form-input" />
                </div>
                <div className="form-group">
                  <label className="form-label">
                    <input type="checkbox" checked={product.isFeatured} onChange={e => setProducts(prev => prev.map(p => p._id === product._id ? { ...p, isFeatured: e.target.checked } : p))} onBlur={() => updateProduct(product._id, 'isFeatured', product.isFeatured)} /> Featured Product
                  </label>
                </div>
                <button onClick={() => deleteProduct(product._id)} className="action-button delete-button">🗑 DELETE</button>
              </div>
            ))}
          </div>
        ) : <p style={{ color: '#aaa' }}>No products found</p>}
      </div>

      <div className="form-section">
        <h3 className="section-header">SUBMITTED ORDERS ({orders.length})</h3>
        {orders.length > 0 ? (
          <div className="product-grid">
            {orders.map(order => (
              <div key={order._id} className="order-card">
                <div className="order-header">
                  <h4 className="order-id">ORDER #{order._id.slice(-6).toUpperCase()}</h4>
                  <p className="order-date">{new Date(order.createdAt).toLocaleString()}</p>
                </div>
                <div className="form-group">
                  <label className="form-label">STATUS</label>
                  <div className="order-status">
                    <select value={order.status || 'pending'} onChange={e => handleStatusUpdate(order._id, e.target.value)} className="status-select">
                      <option value="pending">PENDING</option>
                      <option value="processing">PROCESSING</option>
                      <option value="shipped">SHIPPED</option>
                      <option value="delivered">DELIVERED</option>
                      <option value="cancelled">CANCELLED</option>
                    </select>
                    {orderStatus[order._id] === 'saving' && <span className="status-indicator saving">⏳</span>}
                    {orderStatus[order._id] === 'saved' && <span className="status-indicator saved">✅</span>}
                    {orderStatus[order._id] === 'error' && <span className="status-indicator error">❌</span>}
                  </div>
                </div>
                <div className="order-items">
                  <h5 className="form-label">ITEMS:</h5>
                  <ul className="items-list">
                    {order.items.map((item, i) => <li key={i}>{item.name} - <strong>${item.price.toFixed(2)}</strong></li>)}
                  </ul>
                </div>
                <p className="order-total">TOTAL: ${order.total?.toFixed(2) || order.items.reduce((sum, item) => sum + item.price, 0).toFixed(2)}</p>
              </div>
            ))}
          </div>
        ) : <p style={{ color: '#aaa' }}>No orders found</p>}
      </div>
    </div>
  );
}
