// frontend/src/pages/SuccessPage.jsx
import React, { useEffect, useState } from 'react';
import { useCart } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';
import './SuccessPage.css';

function SuccessPage() {
  const { clearCart } = useCart();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Load last cart items from localStorage
  useEffect(() => {
    const fetchOrder = async () => {
      const cartItems = localStorage.getItem('cartItems');
      if (cartItems) {
        try {
          const parsed = JSON.parse(cartItems);
          const total = parsed.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0);
          setOrder({
            orderId: `HF-${Math.floor(Math.random() * 1000000)}`,
            items: parsed,
            total
          });
        } catch (err) {
          console.error('Checkout error:', err);
        
          try {
            const text = await err.response?.text?.();
            console.log('🔍 Error body:', text);
          } catch (parseErr) {
            console.warn('⚠️ Could not parse error body:', parseErr);
          }
        
          alert('⚠️ Something went wrong during checkout. See console for details.');
        }
      }
      localStorage.removeItem('cartItems'); // Only remove after parsing
      clearCart(); // Clear the live cart context
      setLoading(false);
    };

    fetchOrder();
  }, [clearCart]);

  const handleReturn = () => {
    navigate('/');
  };

  if (loading) {
    return (
      <div className="loading-spinner">
        <div className="spinner" />
        <p>Finalizing your order...</p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="success-container">
        <div className="success-card">
          <h2 className="success-title">Order not found</h2>
          <p className="success-message">We couldn’t retrieve your order. Please check your email or try again later.</p>
          <button className="return-button" onClick={handleReturn}>Return to Store</button>
        </div>
      </div>
    );
  }

  return (
    <div className="success-container">
      <div className="success-card">
        <div className="success-icon">✅</div>
        <h2 className="success-title">Order Placed Successfully!</h2>
        <p className="success-message">Thank you for your order. A confirmation email has been sent.</p>

        <div className="order-summary">
          <h3>Order Summary</h3>
          <p className="order-id">Order ID: {order.orderId}</p>
          <div className="order-items">
            <h4>Items:</h4>
            <ul>
              {order.items.map((item, index) => (
                <li key={index}>
                  {item.name} × {item.quantity || 1} - ${item.price.toFixed(2)}
                </li>
              ))}
            </ul>
            <p className="order-total">Total: ${order.total.toFixed(2)}</p>
          </div>
        </div>

        <div className="disclaimer">
          <h3>Legal & Ethical Disclaimer</h3>
          <p>
            This product is intended for ethical hacking, education, and authorized testing only.
            Misuse may violate laws and result in serious consequences.
          </p>
        </div>

        <button className="return-button" onClick={handleReturn}>🏠 Return to Store</button>
      </div>
    </div>
  );
}

export default SuccessPage;
