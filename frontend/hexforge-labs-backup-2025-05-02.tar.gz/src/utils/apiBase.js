// frontend/src/utils/apiBase.js
const API_BASE_URL = '/api'; // Uses NGINX reverse proxy
export default API_BASE_URL;
