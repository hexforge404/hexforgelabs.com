import React from 'react';
import { useCart } from '../context/CartContext';
import '../pages/AdminPage.css';
import API_BASE_URL from '../utils/apiBase';

function CartDrawer({ isOpen, onClose }) {
  const { cart, removeFromCart, clearCart } = useCart();
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handleCheckout = async () => {
    if (cart.length === 0) {
      alert('⚠️ Your cart is empty!');
      return;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/payments/create-checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: cart }),
        credentials: 'include',
      });

      const data = await res.json();
      if (data.url) {
        // Save cart to localStorage before redirecting
        localStorage.setItem('cartItems', JSON.stringify(cart));
        window.location.href = data.url;
      } else {
        alert('❌ Stripe Checkout failed. No URL received.');
      }
    } catch (err) {
      console.error('Checkout error:', err);
      alert('⚠️ Something went wrong during checkout.');
    }
  };

  return (
    isOpen && (
      <div className="cart-overlay" onClick={onClose}>
        <div className={`cart-drawer ${isOpen ? 'open' : ''}`} onClick={(e) => e.stopPropagation()}>
          <h3 className="cart-header">🛒 Your Cart</h3>
          <div className="cart-items-container">
            {cart.length === 0 ? (
              <p className="empty-cart-message">🛒 Your cart is empty.</p>
            ) : (
              cart.map((item, index) => (
                <div key={index} className="cart-item">
                  <div className="item-details">
                    <strong>{item.name}</strong>
                    <div className="item-price">${item.price.toFixed(2)}</div>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item)} 
                    className="action-button danger-button"
                  >
                    Remove
                  </button>
                </div>
              ))
            )}
          </div>

          <p className="cart-total">
            Total: <span className="total-amount">${total.toFixed(2)}</span>
          </p>

          <button 
            onClick={handleCheckout} 
            className="action-button primary-button checkout-button"
          >
            ✅ Proceed to Checkout
          </button>

          <button 
            onClick={onClose} 
            className="action-button secondary-button close-button"
          >
            Close
          </button>
        </div>
      </div>
    )
  );
}

export default CartDrawer;
