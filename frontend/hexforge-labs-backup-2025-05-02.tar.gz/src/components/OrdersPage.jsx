import React, { useEffect, useState } from 'react';

function OrdersPage() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetch('/api/orders')
      .then(res => res.json())
      .then(data => {
        console.log('Fetched orders:', data);
        setOrders(data.data || []); // 👈 use `data.data` safely
      })
      .catch(err => {
        console.error('Failed to fetch orders:', err);
      });
  }, []);

  console.log('Rendering orders:', orders);

  return (
    <div>
      <h2 style={{ color: '#00ffc8' }}>Orders</h2>
      {orders.length === 0 ? (
        <p style={{ color: '#ccc' }}>No orders yet.</p>
      ) : (
        <ul>
          {orders.map((order) => (
            <li key={order._id}>
              {order.customerName} - {order.total} USD
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default OrdersPage;
